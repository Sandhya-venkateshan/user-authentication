package com.test.user_authentication.Repository;

public interface AuthenticationRepository {
}
